import firebase from "../../Firebase";
import { toast } from 'react-toastify';

export let Createuser = (email, password,phonenumber) => {
  return async dispatch => {
    let userData = await firebase
      .auth()
      .createUserWithEmailAndPassword(email, password,phonenumber);
      userData.user.sendEmailVerification();
    dispatch({
      type: "CREATE_USER",
      payload: userData,
    });
  };
};
export let Loginuser = (email, password) => {
  return async dispatch => {
    let LoginUser = await firebase.auth().signInWithEmailAndPassword(email,password);
    if (LoginUser.emailVerified === true) {
      toast.error("successfully mail verified")
    }
    else {
      toast.error("verified mail")
    }
    dispatch({
      type: "LOGIN_USER",
      payload:LoginUser
    })
  }
}
