import { combineReducers } from "redux";
import AuthReducer from './AuthReducer';
let reducers = combineReducers({ AuthReducer })
export default reducers;
