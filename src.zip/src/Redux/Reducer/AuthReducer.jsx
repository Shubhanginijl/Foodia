let InitialState = {
    Createusers:[],
}


const AuthReducer = (state=InitialState,action) => {
   switch (action.type) {
     case "CREATE_USER":
           return {
               ...state,
               Createusers:action.payload
            
       }

     default:
    return state
   }
}

export default AuthReducer;
