import React, { Fragment } from "react";
import Navbar from "./Components/Navbar";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
 import { ToastContainer, toast } from 'react-toastify';
  import 'react-toastify/dist/ReactToastify.css';
import Home from "./Components/Home";
import Register from "./Components/Register";

import Signin from './Components/Signin';


const App = () => {
  return (
    <Router>
      <header>
        <Navbar />
      </header>
      <ToastContainer/>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signin" element={<Signin/>} />
        <Route path="/signup" element={<Register />} />
      </Routes>
    </Router>
  );
};

export default App;
