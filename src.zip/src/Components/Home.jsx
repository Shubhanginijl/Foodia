import React from 'react'
import "./component.css"
const Home = () => {
    return (
        <section className='section'>
            <article>
                <div className='image1'>
                    <img src="./img1.jpg" alt="landing" />
                </div>
            </article>
        </section>
    )
}

export default Home
