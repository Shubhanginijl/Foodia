import React, {useEffect} from 'react'
import { useSelector,useDispatch } from 'react-redux';
import { FetchData } from '../Redux/Action';
import './restaurant.css'
const Restaurant = () => {
    let data = useSelector((state) => state.AuthReducer.fetch);
          console.log(data)
          let dispatch = useDispatch();
          useEffect(() => {
            dispatch(FetchData());
          }, [dispatch]);
    return (
            <section>
              <article>
                {data.map((a, i) => (
                  <div key={i}>
                    <img src={a.Poster} alt="poster" />
                  </div>
                ))}
              </article>
            </section>
          );
        };

export default Restaurant
